---
title: 'Hadoop Installation'
---

### Install a VM

See [Linux VM](../vm)

In VirtualBox configuration add an extra VDI disk of 16GB to the VM. It will be dedicated to Hadoop storage.
Mount it to /dfs by adding that line to ```/etc/fsab``` (disable noatime):

```
/dev/sdb1   /data   ext4   defaults,noatime   0 0
```

### Install MySQL

Ambari and some Hadoop components requires a RDBMS to store their configuration and metadata. [MySQL](http://mysql.com/) is an easy choice, but you can also go for PostgresSQL or Oracle.
```sh
# as root
yum install -y mysql-server 
# this package is needed for Ambaru buut downloads a lot of dependencies
yum install -y mysql-connector-java 
service mysqld start
chkconfig mysqld on
/usr/bin/mysql_secure_installation
# /usr/bin/mysqladmin -u root password 'your_db_password' a verifier
mysql -u root -p
SQL> CREATE USER 'dbuser'@'localhost' IDENTIFIED BY 'dbuser_password';
SQL> GRANT ALL PRIVILEGES ON *.* TO 'dbuser'@'localhost';
SQL> CREATE USER 'dbuser'@'<FQDN>' IDENTIFIED BY 'dbuser_password';
SQL> GRANT ALL PRIVILEGES ON *.* TO 'dbuser'@'<FQDN>';
SQL> exit
```

### Install Kerberos
It is not mandatory but since most of professional Hadoop environments are secured by Kerberos, I recommend enabling it. 

https://www.centos.org/docs/5/html/5.1/Deployment_Guide/s1-kerberos-server.html


### Install Ambari

Ambari Repositories http://docs.hortonworks.com/HDPDocuments/Ambari-2.4.1.0/bk_ambari-installation/content/ambari_repositories.html
```sh
# as root
cd /etc/yum.repos.d/
wget -nv http://public-repo-1.hortonworks.com/ambari/centos6/2.x/updates/2.4.1.0/ambari.repo
yum install -y ambari-server ambari-agent
mysql -u dbuser -p
SQL> CREATE DATABASE ambari;
SQL> use ambari;
SQL> source /var/lib/ambari-server/resources/Ambari-DDL-MySQL-CREATE.sql;
SQL> exit
ambari-server setup
# choose oracle JDK 1.8 (will be downloaded automatically) and advanced Configuration/mySQL, follow the instructions
service ambari-agent start
service ambari-server start
```

### Install Hadoop

Installation is done from Ambari
Optionnaly, for a lighter WM disable all alerts end delete the views

Note that Ambari is using yum to download and install the components. In case of a proxy it may be usefull to download them manually prior to run the installation fromp UI. Here are the main packages for HDP 2.5.0 up to Ranger and Atlas:

```sh
yum install zookeeper_2_5_0_0_1245*
yum install hadoop_2_5_0_0_1245*
yum install pig_2_5_0_0_1245*
# DataFu: PIG libraries, mandatory
yum install datafu_2_5_0_0_1245*
yum install storm_2_5_0_0_1245-slider-client
# Slider: YARN monitoring libraries, mandatory
yum install slider_2_5_0_0_1245*
yum install tez_2_5_0_0_1245*
yum install hive_2_5_0_0_1245*
yum install hbase_2_5_0_0_1245*
yum install oozie_2_5_0_0_1245*

# Livy: Spark REST API, mandatory
yum install install livy_2_5_0_0_1245*
yum install spark_2_5_0_0_1245*
yum install ambari-infra-solr*
yum install install kafka_2_5_0_0_1245*
yum install install atlas-metadata_2_5_0_0_1245*
yum install install ranger_2_5_0_0_1245*
```


### Install NiFi 

All details there https://github.com/abajwa-hw/ambari-nifi-service
```sh
sudo git clone https://github.com/abajwa-hw/ambari-nifi-service.git   /var/lib/ambari-server/resources/stacks/HDP/2.5/services/NIFI
service ambari restart
# install from GUI
rm /tmp/*.tar.gz
``




### Install Elasticsearch

To check: https://github.com/maweina/ambari-elk-service

An Ambari plugin exists for Elasticsearch [ambari-elasticsearch-service](https://github.com/Symantec/ambari-elasticsearch-service) but it is obsolete and not working anymore with latest HDP versiond. 
It is installed in /var/lib/ambari-server/resources/stacks/HDP/2.5/services/

Update vesrion to 5.0.2 in metainfo.xml
package/scripts/params.py
from resource_management.libraries.functions.version import format_hdp_stack_version, compare_ver
remove seed node

Here is how to install Elasticsearch, all commands are from user root:

```sh
rpm --import https://artifacts.elastic.co/GPG-KEY-elasticsearch
echo "[elasticsearch-5.x]
name=Elasticsearch repository for 5.x packages
baseurl=https://artifacts.elastic.co/packages/5.x/yum
gpgcheck=1
gpgkey=https://artifacts.elastic.co/GPG-KEY-elasticsearch
enabled=1
autorefresh=1
type=rpm-md" >/etc/yum.repos.d/elasticsearch.repo
yum install elasticsearch
	
# data direcrory for Es 
mkdir /dfs/es
chown elasticsearch:elasticsearch /dfs/es
# Edit /etc/sysconfig/elasticsearch
JAVA_HOME=/usr/jdk64/jdk1.8.0_60
ES_JAVA_OPTS=-Djava.net.preferIPv4Stack=true
# Edit /etc/elasticsearch/elasticsearch.yml
cluster.name: es
node.name: ${HOSTNAME}
path.data: /dfs/es
transport.host: _local_
http.host: _eth1_  # the host-only adapter
# Reduce heap in /etc/elasticsearch/jvm.options
service elasticsearch start
```

