---
title: Hive
---

## Overview
Apache [Hive](https://hive.apache.org/) is not a database but a data warehouse software on top of HDFS as described on [Wikipedia](https://en.wikipedia.org/wiki/Apache_Hive). And although Hive [Query Language](https://cwiki.apache.org/confluence/display/Hive/LanguageManual) is closed to ANSI SQL; it has big differences and some major limitations such as UPDATEs not *really* supported, and multiple sub-queries neither.

The main application of Hive is to build structured data-lakes and replace corporate warehouses, usually expensive, by an open source solutions able to absorbe the data growth.

## Warnings

The major thing to understand is that a SELECT query usually triggers a map-reduce job on YARN whatever this job runs on disks with MapReduce, partially in memory (Hive/TEZ) or mostly in memory (Hive on Spark). Some complex queries using JOINs may trigger several jobs.
So the execution and answer time depends upon available resources at execution time, and a query may NOT be answered at all.

The other point is that an INSERT query creates one or more files, and Hive will not optimise or aggregate those files automatically on long term which may result to thousands of small HDFS files, which impact the HDFS services and Hive performances.

## Recommendations
* Use ORC format for internal tables
* Use partitions for big tables and for historic tables (typically a 1 partition = 1 month) 
* 



