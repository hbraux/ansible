---
title: Home
---

### About

This site is not a blog but a collection of technical articles and tutorials in IT domain. It's aim is to share knowledge but also to keep track of  details that I usually don't remember after some time. 

---
### Some useful links
<br>
#### Mandatory stuff
* [JDK 1.8](http://www.oracle.com/technetwork/java/javase/downloads/jdk8-downloads-2133151.html), worth mentioning it?
* [kitty](http://www.9bis.net/kitty), a putty clone with ability to save passwords (not a good practice though) but also to run commands at login
* [Eclipse](https://eclipse.org), no serious Java coding without Eclipse
* [Notepad++](https://notepad-plus-plus.org). I also recommend those plugins: NppFTP, Compare, XML Tools
* [7zip](http://www.7-zip.org) will replace all other zip softwares
* [WinSCP](https://winscp.net) to transfer files using (s)ftp
* [Sumatra PDF](https://www.sumatrapdfreader.org), a fast and light PDF reader, the opposite of Adobe Reader 

#### Other stuff
* [freemind](http://freemind.sourceforge.net/wiki/index.php/Main_Page), to build heuristic maps, in other words draw your ideas in a tree 
* [OpenOffice Draw](http://www.openoffice.org), to design architecture schemas (MS Visio is better but requires a license)
* Oracle [SQL Developper](http://www.oracle.com/technetwork/developer-tools/sql-developer/overview/index.html), supports obviously Oracle database but also MySQL/Mariadb and Hive through 3rd party drivers.
 
---
### Some articles

* Install a [Linux VM](../vm) 
* Install [Hadoop](../hadoop) 

---
This site was built with [Grav](../Grav) and runs on a [Linux VM](../vm) hosted by [OVH](https://www.ovh.com/) (VPS server [SSD1](https://www.ovh.com/fr/vps/vps-ssd.xml))

