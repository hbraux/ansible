---
title: Grav
---

### Overview
My previous site was running with WordPress but I switched to [Grav](https://getgrav.org/) for several reasons: a lighter framework (no DB), the use of flat files in [Markdown](http://learn.getgrav.org/content/markdown) format which is a good compromise, and the ability to backup easily the content of the site.

### Installation on CentOS 6

Prerequisite is to  install [Apache HTTP Server](https://httpd.apache.org/) and at least PHP 5.4

```sh
yum install httpd mod_ssl openssl
service httpd start
chkconfig httpd on
yum install  epel-release
rpm -Uvh  https://centos6.iuscommunity.org/ius-release.rpm
yum install php56u php56u-xml php56u-gd php56u-intl php56u-mbstring
```

Configure HTTP (```/etc/httpd/conf/httpd.conf```) to
* reduce memory footprint (recommended for a small server)
* enable *override* in .htaccess for allowing Grav updating the files 

```properties
Timeout 15
KeepAlive On
MaxKeepAliveRequests 50
KeepAliveTimeout 10
<IfModule prefork.c>
	StartServers          1
    MinSpareServers       1
    MaxSpareServers       3
    MaxClients            10
    MaxRequestsPerChild   3000

<Directory "/var/www/html">
    ...
    AllowOverride All
```
! TODO: how to generate certificates

The last stage is to download and install Grav [Core package](http://getgrav.org/downloads/)
 
```ssh
wget https://github.com/getgrav/grav/releases/download/1.1.8/grav-v1.1.8.zip
unzip grav*.zip 
mv grav/* /var/www/html/
mv grav/.htaccess /var/www/html/
cd /var/www/html/
# behind a proxy, edit /etc/php.ini and set allow_url_fopen=Off
# Upgrade and install admin module  
bin/gpm selfupgrade
bin/gpm install admin 
# usefull plugins 
bin/gpm install highlight
# permissions
chown –R apache:apache *
# restart
service httpd restart
```

### Configuration

Open GRAV UI [http://localhost/admin](http://localhost/admin) and create admin account with a solid password

Then connect to Admin panel:

* select *Configuration*, tab *Site* and update *Defaults*
* select *Plugins*, tab *Admin*
  * Replace *Administrator path* /admin by another path to enforce security
  * Disable *feeds* and *notifications* (useless for me)

Install a theme with **GPM**. This one is***Developer*** .
```sh
cd /var/www/html
sudo bin/gpm install developer
```


### Editing

Create new pages from Admin console.

To update pages, use either the console or manually edit the files /var/www/html/user/pages/*/default.md 



