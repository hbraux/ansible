---
title: HBase
---

# Overview


# Recommandations
* Avoir region hotspotting: use composite keys or UUIDs
* Avoid small rows (max recommended ~ 10000 columns)
* Do not store blobs; write files on HDFS and keep a URL
* Denormalize data by creating additional tables for indexing for instance
* Use dynamic columns for handling relationships assocaietd with a dedicated family

