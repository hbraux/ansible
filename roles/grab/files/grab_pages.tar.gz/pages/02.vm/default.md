---
title: 'Linux VM'
---

## Why?

Windows is usually the mandatory OS for professional desktops for many good reasons such as security, maintenance, office software such as MS Office or Outlook 360.

Though most of business applications are now running under Linux and their development requires at least a server for testing purpose, which you don't always have especially when servers usage is restricted by company policies or LAN connection requires VPN. The good solution is to install a Linux VM (or more) on your Windows host so that you can do whatever you want.

---
## Installation 
<br>
### Distribution
For many years I have used [Gentoo](https://www.gentoo.org/) a source distribution system, relying on very nice package manager called  [Portage](https://fr.wikipedia.org/wiki/Portage_(Gentoo)); basically the code is compiled when installing the package.

Now I am using [CentOS](https://en.wikipedia.org/wiki/CentOS), mostly in version 6. CentOS is an open source clone of RedHat and comes with the package manager [yum](https://en.wikipedia.org/wiki/Yellowdog_Updater,_Modified). It's installation is quite straightforward. 

### Hypervisor and VM Configuration
I recommend Oracle [VirtualBox](https://www.virtualbox.org/). Below the settings for a "big" server, able to run a [Hadoop](../hadoop) distribution from Cloudera or Hotonworks with all the components enabled
* General &rarr; Basic: name "linux", type Linux, Redhat 64
* System &rarr; Motherboard &rarr; Memory: assign maximum of RAM (just let 3 GB to Windows)
* System &rarr; Processor: assign all CPUs but 2 
* Storage &rarr; SATA: add a VDI disk with dynamic allocation, at leat 16GB, stored preferably on a SSD (enable option *solo-state drive*)
* Network &rarr; Card 1: host-only adapter to setup a private network between Windows and the VM. Configure in Preferences &rarr; Network  the host-only network, for instance 192.168.56.0 and DHCP to assign addresses from 192.168.56.101 (the DHCP is temporary, just used for installation)
* Network &rarr; Card 2: NAT for internet access
* Audio: disabled
* USB: disabled
* Shared folders: disabled

### Installing CentOS 6
* Download an ISO file CentOS-6.***N***-x86_64-minimal.iso from <http://isoredirect.centos.org/centos/6/isos/x86_64/>
* Mount ISO in VirtualBox: Storage &rarr; IDE &rarr; Optical drive &rarr; Live CD
* Start the VM, select option Install or Upgrade, and follow the wizard: 
* Skip disk checking
* Select language (*English*!), the appropriate keyboad, Basic storage, ATA disk by default, and a hostname for instance *linux.hostonly.com* 
* In Configure Network, enable Connect Automatically for eth0 and eth1
* Select the timezone 
* Enter a password for *root*
* Select option "Replace existing.." but install with manual partitioning by clicking on bottom checkbox which I DO recommend. Delete the existing configuration and et re-create 3 standard partitions (save when done):  
 * sda1, ext4, /boot, 200M 
 * sda2, swap, 800M
 * sda3, ext4, / , *everything's left*
* Install boot loader on the first partion /dev/sda1
* Save, wait for installation to complete and reboot

### Connectivity
* Login to VM with putty through the host-only network and the IP assigned by DHCP (should be 192.168.56.101), user root 
* Edit with vi the file ```/etc/sysconfig/network-scripts/ifcfg-eth0``` to disable DHCP and assign a fixed IP to the VM

```properties
BOOTPROTO=static
IPADDR=192.168.56.2
```
* Check domain name in ```/etc/sysconfig/network```
* Stop the VM: ```halt```
* In VirtualBox unmount the Live CD and restart the VM
* Add following line Windows hosts (usually ```C:\Windows\System32\drivers\etc\hosts```)

```properties
192.168.56.2 linux.hostonly.com
```

* Connect with putty to this hostname, user *root*
* Check internet connectivity and upgrade OS with```yum -y update```
* For proxies add following lines to your `/root/.bashrc` 
```properties
export http_proxy=http://<proxy>:<port>
export https_proxy=http://<proxy>:<port>
```

### Completion
* Install those useful packages
```ssh
 yum -y install nano lynx curl git emacs-nox
```
* Allow users from *wheel* group to sudo by un-commenting this line in `/etc/sudoers`
```properties
%wheel  ALL=(ALL)       NOPASSWD: ALL
```
* Create your user for instance
```ssh
useradd harold -g users -G wheel
passwd harold
su - harold
ssh-keygen -t rsa -b 4096
```
* Customize the prompt  `.bashrc`
```properties
PS1='\[\033[1;32m\]\u@\h:\[\033[1;34m\] \w \$ \[\033[0m\]'
```

### Additional Services
Install ntp to keep server on time :```yum install ntp```


---
## Security
The security shall be enforced for a Linux VM in the Cloud:
* in file ```/etc/ssh/sshd_config``` replace SSH port by 8443 (usually open by proxies) and disable root access by setting ```PermitRootLogin=No```. Restart the service (```service sshd restart```)
* Generate a RSA key with [puttygen](http://www.chiark.greenend.org.uk/) for a secured access, backup this key on a secured place (USB drive)
* Configure putty to use the private key, and add the public key to```.ssh/authorized_keys``` on the server 
* Change root password to something's strong
* Add firewall rule's via iptables by allowing port 8843 and other
```ssh
iptables --line-numbers -v -L
iptables -I INPUT 5 -p tcp --dport 8443 -j ACCEPT
service iptables save
service sshd restart
```




