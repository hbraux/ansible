---
title: Hadoop
---

## Context
I'm using [Apache Hadoop](http://hadoop.apache.org/) on physical clusters hosted by corporate Data Centers, and also on a VM running on my computer. This latter option is really convenient to install early releases or additional componenents which may not be available on the real clusters.


### Distributions
I have both installed [Hortonworks](http://hortonworks.com) *HDP* and [Cloudera](http://cloudera.com/) CDH, though I would recommend HDP for 
a personal cluster on a VM, especially as [Ambari](https://ambari.apache.org/) is an open framework allowing installation of third parties like 
ElasticSerach or Nifi on the same server.

Although you can download directy a sandbox (VM image with Hadoop on it) I recommend installing everything from scratch to learn a bit of experience regarding Hadoop administration. Fortunately Ambari makes it easy. There are a couple of pre-requisites though.

### Installation

See [Hadoop Installation](../hadoop_install)

