---
title: Security
---

## Passwords

Some considerations regadding passwods on internet.


## SSH Keys

*To be completed*

## Connection through proxy
It may be useful to connect from work to a personal server or computer. Unfortunately most of Enterprise proxies block non standard ports (other than HTTP). Here are a few options to bypass this.

### SSH with HTTPS port(s)
Edit the file ```/etc/ssh/sshd_config``` and configure an additional port for SSH server: 8443 (alternative HTTPS port)
Restart the server ```sudo service sshd restart``` and try to connect from work.

If not working do the same with port 443. If it works, great! The only remaining problem is the port conflict in case you need to run an Apache server with SSL. A solution exists:[sslh](http://www.rutschle.net/tech/sslh.shtml) which is a protocol router allows handling both SSL and SSH on the same listening port (443) , and route them to other local ports (either 22 for SSH, or 1444 for SSL assuming that you have reconfigured your Apache Server on  that one)

### Shellinabox

*To be completed*

### SSL Tunnel

This is the ultimate option, [Stunnel](https://www.stunnel.org/index.html) creates a SSL tunnel on port 443. It requires installing the software on client too.  

Serveur side
```ssh
yum install stunnel
# create file /etc/stunnel/stunnel.conf 
cert = /etc/pki/tls/certs/stunnel.pem
setuid = nobody
pid = /var/run/stunnel/stunnel.pid
[ssh]
accept = 8443
connect = localhost:22
```

client side (Linux)
```ssh

# conf client
cat /etc/stunnel/stunnel.conf
pid = /var/run/stunnel/stunnel.pid
cert = /etc/stunnel/stunnel.pem
client = yes
# foreground = yes # for debugging
[ssh]
accept = 127.0.0.1:2222
protocol = connect
protocolAuthentication = basic
protocolHost = <your home ip>:443
connect = proxy :port

# creation of stunnel.pem
openssl genrsa -out key.pem 2048
openssl req -new -x509 -key key.pem -out cert.pem -days 1095
cat key.pem cert.pem >> /etc/stunnel/stunnel.pem
chmod 400 /etc/stunnel/stunnel.pem
# debug
mkdir /var/run/stunnel
/usr/bin/stunnel /etc/stunnel/stunnel.conf
ssh -p8443 localhost
```

