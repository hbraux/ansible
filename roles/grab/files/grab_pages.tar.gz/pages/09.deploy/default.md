---
title: Deployment
---

The purpose is to quickly deploy on-demand Linux VMs that run Elasticsearch, Kafka or any other Big Data component.

# Environment

* Hosting server: Windows 7 
* Hypervisor: Oracle [VirtualBox](https://www.virtualbox.org/) 
# Guest OS: [CentOS](https://www.centos.org/) 7
* Guest Configuration: [Vagrant)(https://www.vagrantup.com/)
* Guest Installation: [Ansible](https://www.ansible.com)

# Vagrant

Vagrant allows building server for VirtualBox or any other Hypervisor from images containing a basic OS installation.
Like VirtualBox, Vagrant must be installed on the hosting server for instance Windows 7 (if vagrant commands freeze, also install the latest version of PowerShell)

The images for CentOS 7 can be downloaded from here http://cloud.centos.org/centos/7/vagrant/x86_64/images/
When done run from command prompt `vagrant box add centos/7 CentOS-7-....box` to load the box (from the directory where file resides)
Create a `Vagrantfile` that defines the VM setting for instance for ELK
```
# Vagrant File for ELK servers elk<N>.hostonly.com with internal IP 192.168.56.5<N>
Vagrant.configure("2") do |config|
	ssh_pub_key = File.readlines("id_rsa.pub").first.strip
	(1..2).each do |i|
		config.vm.define "elk#{i}" do |node|
			node.vm.box = "centos/7"
			node.vm.network :private_network, ip: "192.168.56.5%d" % i
			node.vm.hostname = "elk#{i}.hostonly.com"
			node.vm.provision 'shell', inline: "echo #{ssh_pub_key} >> /home/vagrant/.ssh/authorized_keys", privileged: false
			node.vm.provider "virtualbox" do |v|
			  v.name = "elk#{i}"
		      v.customize ["modifyvm", :id, "--memory", "1024"]
			  v.customize ["modifyvm", :id, "--cpus", 1]
		    end
	     end
	end
end
```
Copy your public key to local file `id_rsa.pub` and run `vagrant up` to start the VM(s)
Then you should be able to login with SSH on user `ansible` which has sudo permissions

Note: to troubleshoot, add `--debug` to command line

# Ansible

Ansible is run from a dedicated CentOS VM that is a both an admin node and an edge node.
After installation with yum, override the default configuration with `$HOME/.ansible.cfg`
```
[defaults]
# default inventory file
inventory = hosts.ini
# default deployment user is vagrant
remote_user = vagrant
# no check on host
host_key_checking = False
# no retry
retry_files_enabled = False
```

In the main inventory file `$HOME/hosts.ini` we define all servers by ranges
```
[elk]
elk[1:9].hostonly.com

[kafka]
kafka[1:9].hostonly.com

[nifi]
nifi[1:9].hostonly.com
```
Don't forget to add all hosts IPs in `/etc/hosts` according to Vagrant configuration

check the hosts and the connections
```ssh
ansible  all -m ping
```

The rest of configuration will rely in Git. Create a Git project and clone it locally. Within this project, create a directory `ansible` that will contain everything


# Docker
